
// (Trimmed in this code block for clarity)
// The actual content will include all logic from previous MainViewModel.cs response
