﻿using System.Windows;

namespace CodeLineCounterApp

{

    public partial class App : Application

    {

    }

}
