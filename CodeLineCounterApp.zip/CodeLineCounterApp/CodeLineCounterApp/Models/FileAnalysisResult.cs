﻿namespace CodeLineCounterApp.Models
{
    public class FileAnalysisResult
    {
        public string FileName { get; set; }
        public string FullPath { get; set; }
        public string Extension { get; set; }
        public int LineCount { get; set; }
    }
}