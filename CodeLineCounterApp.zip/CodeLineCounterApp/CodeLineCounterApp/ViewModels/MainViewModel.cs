﻿using CodeLineCounterApp.Models;
using CodeLineCounterApp.Helpers;
using Microsoft.Win32;
using System.Collections.ObjectModel;
using System.IO;
using System.Text.Json;
using System.Windows.Input;
using System.Windows.Forms;
using System.Linq;
using System;

namespace CodeLineCounterApp.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        private string _rootPath;
        private bool _includeSubfolders = true;
        private string _manualExtensions = ".cs\n.xaml";
        private string _manualExcludedPaths = "bin\nobj";
        private int _totalLineCount;
        private int _totalFileCount;
        public string RootPath
        {
            get => _rootPath;
            set { _rootPath = value; OnPropertyChanged(); }
        }
        public bool IncludeSubfolders
        {
            get => _includeSubfolders;
            set { _includeSubfolders = value; OnPropertyChanged(); }
        }
        public string ManualExtensions
        {
            get => _manualExtensions;
            set { _manualExtensions = value; OnPropertyChanged(); }
        }
        public string ManualExcludedPaths
        {
            get => _manualExcludedPaths;
            set { _manualExcludedPaths = value; OnPropertyChanged(); }
        }
        public ObservableCollection<FileAnalysisResult> Results { get; } = new();
        public int TotalLineCount
        {
            get => _totalLineCount;
            set { _totalLineCount = value; OnPropertyChanged(); }
        }
        public int TotalFileCount
        {
            get => _totalFileCount;
            set { _totalFileCount = value; OnPropertyChanged(); }
        }
        public AppSettings Settings { get; set; } = new();
        public ICommand AnalyzeCommand => new RelayCommand(_ => Analyze());
        public ICommand ExportCommand => new RelayCommand(_ => ExportCsv());
        public ICommand LoadJsonCommand => new RelayCommand(_ => LoadJson());
        public ICommand BrowseFolderCommand => new RelayCommand(_ => BrowseFolder());
        private void Analyze()
        {
            Results.Clear();
            TotalLineCount = 0;
            TotalFileCount = 0;
            if (!Directory.Exists(RootPath)) return;
            Settings = new AppSettings
            {
                IncludedExtensions = ManualExtensions.Split(new[] { '\n', '\r', ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(e => e.Trim()).Where(e => e.StartsWith(".")).ToList(),
                ExcludedPaths = ManualExcludedPaths.Split(new[] { '\n', '\r', ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(e => e.Trim()).ToList()
            };
            var allFiles = Directory.GetFiles(RootPath, "*.*", IncludeSubfolders ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly);
            var filteredFiles = allFiles.Where(file =>
                (Settings.IncludedExtensions.Count == 0 || Settings.IncludedExtensions.Contains(Path.GetExtension(file))) &&
                !Settings.ExcludedPaths.Any(p => file.Contains(p))
            ).ToList();
            TotalFileCount = filteredFiles.Count;
            foreach (var file in filteredFiles)
            {
                int lineCount = File.ReadLines(file).Count();
                Results.Add(new FileAnalysisResult
                {
                    FileName = Path.GetFileName(file),
                    FullPath = file,
                    Extension = Path.GetExtension(file),
                    LineCount = lineCount
                });
                TotalLineCount += lineCount;
            }
        }
        private void ExportCsv()
        {
            var dialog = new System.Windows.Forms.SaveFileDialog { Filter = "CSV file (*.csv)|*.csv", FileName = "results.csv" };
            if (dialog.ShowDialog() != DialogResult.OK) return;
            using var writer = new StreamWriter(dialog.FileName);
            writer.WriteLine("FullPath,FileName,Extension,LineCount");
            foreach (var r in Results)
            {
                writer.WriteLine($"{r.FullPath},{r.FileName},{r.Extension},{r.LineCount}");
            }
            writer.WriteLine($",,,Total Files,{TotalFileCount}");
            writer.WriteLine($",,,Total Lines,{TotalLineCount}");
        }
        private void LoadJson()
        {
            var dialog = new Microsoft.Win32.OpenFileDialog { Filter = "JSON file (*.json)|*.json" };
            if (dialog.ShowDialog() != true) return;
            var json = File.ReadAllText(dialog.FileName);
            Settings = JsonSerializer.Deserialize<AppSettings>(json);
            ManualExtensions = string.Join("\n", Settings.IncludedExtensions);
            ManualExcludedPaths = string.Join("\n", Settings.ExcludedPaths);
        }
        private void BrowseFolder()
        {
            using var dialog = new FolderBrowserDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                RootPath = dialog.SelectedPath;
            }
        }
    }
}