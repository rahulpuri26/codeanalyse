﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Serilog;
using System.Windows;
using CodeLineCounterApp.ViewModels;
using CodeLineCounterApp.Views;
using System;
namespace CodeLineCounterApp
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)

        {
            Log.Logger = new LoggerConfiguration()
                .MinimumLevel.Information()
                .WriteTo.Console()
                .WriteTo.File("logs/log.txt", rollingInterval: RollingInterval.Day)
                .CreateLogger();

            Log.Information("========================================");
            Log.Information("New Application Session Started: {Time}", DateTime.Now);
            Log.Information("========================================");
            base.OnStartup(e);
        }

        protected override void OnExit(ExitEventArgs e)
        {
            Log.Information("Application exiting.");
            Log.CloseAndFlush();
            base.OnExit(e);
        }
    }
}