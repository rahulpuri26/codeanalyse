﻿using CodeLineCounterApp.Models;
using CodeLineCounterApp.Helpers;
using System.Collections.ObjectModel;
using System.IO;
using System.Text.Json;
using System.Windows.Input;
using System.Linq;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System;
using Serilog;
using OpenFileDialog = Microsoft.Win32.OpenFileDialog;
using SaveFileDialog = Microsoft.Win32.SaveFileDialog;
namespace CodeLineCounterApp.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        private string _rootPath;
        private bool _includeSubfolders = true;
        private string _manualExtensions = ".cs\n.xaml";
        private string _manualExcludedPaths = "bin\nobj";
        private int _totalLineCount;
        private int _totalFileCount;
        private int _totalMethodCount;
        public string RootPath
        {
            get => _rootPath;
            set { _rootPath = value; OnPropertyChanged(); }
        }
        public bool IncludeSubfolders
        {
            get => _includeSubfolders;
            set { _includeSubfolders = value; OnPropertyChanged(); }
        }
        public string ManualExtensions
        {
            get => _manualExtensions;
            set { _manualExtensions = value; OnPropertyChanged(); }
        }
        public string ManualExcludedPaths
        {
            get => _manualExcludedPaths;
            set { _manualExcludedPaths = value; OnPropertyChanged(); }
        }
        public int TotalLineCount
        {
            get => _totalLineCount;
            set { _totalLineCount = value; OnPropertyChanged(); }
        }
        public int TotalFileCount
        {
            get => _totalFileCount;
            set { _totalFileCount = value; OnPropertyChanged(); }
        }
        public int TotalMethodCount
        {
            get => _totalMethodCount;
            set { _totalMethodCount = value; OnPropertyChanged(); }
        }
        public ObservableCollection<FileAnalysisResult> Results { get; } = new();
        public AppSettings Settings { get; set; } = new();
        public ICommand AnalyzeCommand => new RelayCommand(_ => Analyze());
        public ICommand ExportCommand => new RelayCommand(_ => ExportCsv());
        public ICommand LoadJsonCommand => new RelayCommand(_ => LoadJson());
        public ICommand SaveJsonCommand => new RelayCommand(_ => SaveJson());
        public ICommand BrowseFolderCommand => new RelayCommand(_ => BrowseFolder());
        private void Analyze()
        {
            Results.Clear();
            TotalFileCount = 0;
            TotalLineCount = 0;
            TotalMethodCount = 0;
            if (!Directory.Exists(RootPath))
            {
                Log.Warning("Root path does not exist: {RootPath}", RootPath);
                return;
            }
            try
            {
                Settings = new AppSettings
                {
                    IncludedExtensions = ManualExtensions.Split(new[] { '\n', '\r', ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                        .Select(e => e.Trim()).Where(e => e.StartsWith(".")).ToList(),
                    ExcludedPaths = ManualExcludedPaths.Split(new[] { '\n', '\r', ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                        .Select(e => e.Trim()).ToList()
                };
                Log.Information("Analysis started on folder: {RootPath} (Subfolders: {Subfolders})", RootPath, IncludeSubfolders);
                var allFiles = Directory.GetFiles(RootPath, "*.*", IncludeSubfolders ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly);
                var filteredFiles = allFiles.Where(file =>
                    (Settings.IncludedExtensions.Count == 0 || Settings.IncludedExtensions.Contains(Path.GetExtension(file))) &&
                    !Settings.ExcludedPaths.Any(p => file.Contains(p))
                ).ToList();
                TotalFileCount = filteredFiles.Count;
                foreach (var file in filteredFiles)
                {
                    int lineCount = File.ReadLines(file).Count();
                    string code = File.ReadAllText(file);
                    int methodCount = CountMethods(code);
                    Results.Add(new FileAnalysisResult
                    {
                        FileName = Path.GetFileName(file),
                        FullPath = file,
                        Extension = Path.GetExtension(file),
                        LineCount = lineCount,
                        MethodCount = methodCount
                    });
                    TotalLineCount += lineCount;
                    TotalMethodCount += methodCount;
                }
                Log.Information("Analysis complete: Files={FileCount}, Lines={LineCount}, Methods={MethodCount}",
                    TotalFileCount, TotalLineCount, TotalMethodCount);
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Exception occurred during analysis.");
            }
        }
        private int CountMethods(string code)
        {
            var methodRegex = new Regex(@"\b(?:public|private|protected|internal|static|\s)*\s+\w[\w\d_<>]*\s+\w+\s*\([^)]*\)\s*{", RegexOptions.Compiled);
            return methodRegex.Matches(code).Count;
        }
        private void ExportCsv()
        {
            var dialog = new SaveFileDialog { Filter = "CSV file (*.csv)|*.csv", FileName = "results.csv" };
            if (dialog.ShowDialog() != true) return;
            try
            {
                using var writer = new StreamWriter(dialog.FileName);
                writer.WriteLine("FullPath,FileName,Extension,LineCount,MethodCount");
                foreach (var r in Results)
                {
                    writer.WriteLine($"{r.FullPath},{r.FileName},{r.Extension},{r.LineCount},{r.MethodCount}");
                }
                writer.WriteLine($",,,Total Files,{TotalFileCount}");
                writer.WriteLine($",,,Total Lines,{TotalLineCount}");
                writer.WriteLine($",,,Total Methods,{TotalMethodCount}");
                Log.Information("CSV export successful to {Path}", dialog.FileName);
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Error during CSV export.");
            }
        }
        private void LoadJson()
        {
            var dialog = new OpenFileDialog { Filter = "JSON file (*.json)|*.json" };
            if (dialog.ShowDialog() != true) return;
            try
            {
                var json = File.ReadAllText(dialog.FileName);
                Settings = JsonSerializer.Deserialize<AppSettings>(json);
                ManualExtensions = string.Join("\n", Settings.IncludedExtensions);
                ManualExcludedPaths = string.Join("\n", Settings.ExcludedPaths);
                Log.Information("Config loaded from JSON: {Path}", dialog.FileName);
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Failed to load JSON config");
            }
        }
        private void SaveJson()
        {
            var dialog = new System.Windows.Forms.SaveFileDialog
            {
                Filter = "JSON file (*.json)|*.json",
                FileName = "config.json"
            };
            if (dialog.ShowDialog() != DialogResult.OK) return;
            try
            {
                var config = new AppSettings
                {
                    IncludedExtensions = ManualExtensions
                        .Split(new[] { '\n', '\r', ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                        .Select(e => e.Trim()).ToList(),
                    ExcludedPaths = ManualExcludedPaths
                        .Split(new[] { '\n', '\r', ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                        .Select(e => e.Trim()).ToList()
                };
                var json = JsonSerializer.Serialize(config, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(dialog.FileName, json);
                Log.Information("Config saved to JSON: {Path}", dialog.FileName);
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Failed to save config JSON");
            }
        }
        private void BrowseFolder()
        {
            using var dialog = new FolderBrowserDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                RootPath = dialog.SelectedPath;
                Log.Information("Folder selected: {Folder}", RootPath);
            }
        }
    }
}