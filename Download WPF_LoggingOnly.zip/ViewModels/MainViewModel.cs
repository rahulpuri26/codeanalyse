
using System;
using System.Collections.ObjectModel;
using Microsoft.Extensions.Logging;
using CodeLineCounterApp.Models;

namespace CodeLineCounterApp.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        private readonly ILogger<MainViewModel> _logger;

        public ObservableCollection<FileAnalysisResult> Results { get; set; }

        public MainViewModel(ILogger<MainViewModel> logger)
        {
            _logger = logger;
            _logger.LogInformation("MainViewModel initialized.");
            Results = new ObservableCollection<FileAnalysisResult>();
        }

        public void Analyze()
        {
            try
            {
                _logger.LogInformation("Analysis started.");

                // Simulated logic
                Results.Clear();

                _logger.LogInformation("Analysis completed.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred during analysis.");
            }
        }
    }
}
