using CodeLineCounterApp.Models;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace CodeLineCounterApp.Repositories
{
    public class FileAnalysisRepository : IFileAnalysisRepository
    {
        public IEnumerable<FileAnalysisResult> AnalyzeFiles(string rootPath, AppSettings settings, bool includeSubfolders)
        {
            var option = includeSubfolders ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly;

            var files = Directory.GetFiles(rootPath, "*.*", option)
                .Where(file => settings.IncludedExtensions.Any(ext => file.EndsWith(ext, System.StringComparison.OrdinalIgnoreCase)))
                .Where(file => !settings.ExcludedPaths.Any(p => file.Contains(p, System.StringComparison.OrdinalIgnoreCase)));

            foreach (var file in files)
            {
                yield return new FileAnalysisResult
                {
                    FullPath = file,
                    FileName = Path.GetFileName(file),
                    Extension = Path.GetExtension(file),
                    LineCount = File.ReadLines(file).Count()
                };
            }
        }
    }
}