using CodeLineCounterApp.Models;
using System.Collections.Generic;

namespace CodeLineCounterApp.Repositories
{
    public interface IFileAnalysisRepository
    {
        IEnumerable<FileAnalysisResult> AnalyzeFiles(string rootPath, AppSettings settings, bool includeSubfolders);
    }
}