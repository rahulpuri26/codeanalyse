using CodeLineCounterApp.Models;
using CodeLineCounterApp.Repositories;
using Microsoft.Win32;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Windows.Input;
using CsvHelper;
using System.Globalization;

namespace CodeLineCounterApp.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private readonly IFileAnalysisRepository _repository = new FileAnalysisRepository();

        public ObservableCollection<FileAnalysisResult> Results { get; set; } = new();
        public AppSettings Settings { get; set; } = new();

        private bool _useJsonConfig;
        public bool UseJsonConfig
        {
            get => _useJsonConfig;
            set { _useJsonConfig = value; OnPropertyChanged(); }
        }

        private bool _includeSubfolders = true;
        public bool IncludeSubfolders
        {
            get => _includeSubfolders;
            set { _includeSubfolders = value; OnPropertyChanged(); }
        }

        public string RootPath { get; set; } = "";
        public int TotalLineCount { get; set; }

        public ICommand AnalyzeCommand => new RelayCommand(Analyze);
        public ICommand ExportCommand => new RelayCommand(ExportToCsv);
        public ICommand LoadJsonCommand => new RelayCommand(LoadJsonSettings);

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string name = "") =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));

        public void LoadJsonSettings()
        {
            var dialog = new OpenFileDialog { Filter = "JSON files (*.json)|*.json" };
            if (dialog.ShowDialog() == true)
            {
                var json = File.ReadAllText(dialog.FileName);
                Settings = JsonSerializer.Deserialize<AppSettings>(json) ?? new();
                OnPropertyChanged(nameof(Settings));
            }
        }

        public void Analyze()
        {
            Results.Clear();
            TotalLineCount = 0;
            var files = _repository.AnalyzeFiles(RootPath, Settings, IncludeSubfolders);
            foreach (var file in files)
            {
                Results.Add(file);
                TotalLineCount += file.LineCount;
            }
            OnPropertyChanged(nameof(TotalLineCount));
        }

        public void ExportToCsv()
        {
            var dialog = new SaveFileDialog { Filter = "CSV files (*.csv)|*.csv", FileName = "linecount_report.csv" };
            if (dialog.ShowDialog() == true)
            {
                using var writer = new StreamWriter(dialog.FileName);
                using var csv = new CsvWriter(writer, CultureInfo.InvariantCulture);
                csv.WriteRecords(Results);
                writer.WriteLine($"TOTAL FILES,,,{Results.Count}");
                writer.WriteLine($"TOTAL LINES,,,{TotalLineCount}");
            }
        }
    }
}